'use strict';

const Hapi = require('@hapi/hapi');
const Joi = require('@hapi/joi');
const { v4: uuidv4 } = require('uuid');
const { Storage } = require('@google-cloud/storage');
const { Firestore } = require('@google-cloud/firestore');
const fs = require('fs');
const Path = require('path');
const Inert = require('@hapi/inert');

// Initialize Firestore
const firestore = new Firestore();

const init = async () => {
    const server = Hapi.server({
        port: 8080,
        host: '0.0.0.0',
        routes: {
            cors: {
                origin: ['*']
            }
        }
    });

    await server.register(Inert);

    server.route({
        method: 'POST',
        path: '/predict',
        options: {
            payload: {
                maxBytes: 1000000,
                parse: true,
                output: 'file',
                allow: 'multipart/form-data'
            },
            validate: {
                payload: Joi.object({
                    image: Joi.any().meta({ swaggerType: 'file' }).required().description('Image file')
                }),
                failAction: async (request, h, err) => {
                    if (err.isJoi && err.details[0].type === 'any.required') {
                        return h.response({
                            status: 'fail',
                            message: 'Terjadi kesalahan dalam melakukan prediksi'
                        }).code(400).takeover();
                    }
                    throw err;
                }
            }
        },
        handler: async (request, h) => {
            const { image } = request.payload;

            if (!image) {
                return h.response({
                    status: 'fail',
                    message: 'Terjadi kesalahan dalam melakukan prediksi'
                }).code(400);
            }

            try {
                // Simulate model prediction (replace with actual model prediction)
                const result = "Cancer";
                const suggestion = "Segera periksa ke dokter!";

                // Generate unique ID for the prediction
                const predictionId = uuidv4();
                const createdAt = new Date().toISOString();

                // Save prediction to Firestore
                const predictionData = {
                    id: predictionId,
                    result: result,
                    suggestion: suggestion,
                    createdAt: createdAt
                };
                await firestore.collection('predictions').doc(predictionId).set(predictionData);

                return h.response({
                    status: 'success',
                    message: 'Model is predicted successfully',
                    data: predictionData
                });
            } catch (error) {
                console.error(error);
                return h.response({
                    status: 'fail',
                    message: 'Terjadi kesalahan dalam melakukan prediksi'
                }).code(400);
            }
        }
    });

    server.ext('onPreResponse', (request, h) => {
        const response = request.response;
        if (response.isBoom && response.output.statusCode === 413) {
            return h.response({
                status: 'fail',
                message: 'Payload content length greater than maximum allowed: 1000000'
            }).code(413);
        }
        return h.continue;
    });

    await server.start();
    console.log('Server running on %s', server.info.uri);
};

process.on('unhandledRejection', (err) => {
    console.log(err);
    process.exit(1);
});

init();
